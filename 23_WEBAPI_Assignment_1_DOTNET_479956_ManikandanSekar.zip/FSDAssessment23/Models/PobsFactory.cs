﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace FSDAssessment23.Models
{
    public class PobsFactory
    {
        public static string SupplierApiUrl
        {
            get
            {
                return "http://localhost:49897/api";
            }
        }

        private static HttpClient httpClient;
        public static IEnumerable<Supplier> RetriveAllSupplier()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(SupplierApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync($"{SupplierApiUrl }/SuppliersApi").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<Supplier>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        public static Supplier RetriveAllSupplier(string id)
        {
            try
            {
                httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(SupplierApiUrl);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = httpClient.GetAsync($"{SupplierApiUrl}/SuppliersApi/" + id.Trim()).Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<Supplier>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }
        public static bool SaveSupplier(Supplier customer)
        {
            try
            {
                httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(SupplierApiUrl);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = httpClient.PostAsJsonAsync($"{SupplierApiUrl}/SuppliersApi", customer).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
        public static bool UpdateSupplier(Supplier prod)
        {
            try
            {
                httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(SupplierApiUrl);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = httpClient.PutAsJsonAsync($"{SupplierApiUrl}/SuppliersApi/" + prod.SuplNo.Trim(), prod).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
        public static bool DeleteSupplier(string id)
        {
            try
            {
                httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(SupplierApiUrl);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = httpClient.DeleteAsync($"{SupplierApiUrl}/SuppliersApi/" + id.Trim()).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }



    }
}