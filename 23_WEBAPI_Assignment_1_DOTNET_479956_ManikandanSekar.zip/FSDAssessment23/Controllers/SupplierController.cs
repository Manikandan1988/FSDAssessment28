﻿using FSDAssessment23.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FSDAssessment23.Controllers
{
    public class SupplierController : Controller
    {
        // GET: Supplier
        public ActionResult Index()
        {
            var supplierList = PobsFactory.RetriveAllSupplier().ToList();
            return View(supplierList);
        }

        // GET: Supplier/Details/5
        public ActionResult Details(string id)
        {
            return View();
        }

        // GET: Supplier/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Supplier/Create
        [HttpPost]
        public ActionResult Create(Supplier collection)
        {
            try
            {
                // TODO: Add insert logic here

                if (ModelState.IsValid)
                {
                    PobsFactory.SaveSupplier(collection);
                    return RedirectToAction("Index");
                }
                return View(collection);



            }
            catch
            {
                return View();
            }
        }

        // GET: Supplier/Edit/5
        public ActionResult Edit(string id)
        {
            return View(PobsFactory.RetriveAllSupplier(id));
        }

        // POST: Supplier/Edit/5
        [HttpPost]
        public ActionResult Edit(string id, Supplier collection)
        {
            try
            {
                // TODO: Add update logic here

                if (ModelState.IsValid)
                {
                    PobsFactory.UpdateSupplier(collection);
                    return RedirectToAction("Index");
                }
                return View(collection);
            }
            catch
            {
                return View();
            }
        }

        // GET: Supplier/Delete/5
        public ActionResult Delete(string id)
        {
            return View(PobsFactory.RetriveAllSupplier(id));
        }

        // POST: Supplier/Delete/5
        [HttpPost]
        public ActionResult Delete(string id, Supplier collection)
        {
            try
            {
                // TODO: Add delete logic here

                PobsFactory.DeleteSupplier(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
