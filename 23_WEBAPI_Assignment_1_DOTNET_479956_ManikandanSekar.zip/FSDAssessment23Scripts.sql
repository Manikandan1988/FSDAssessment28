--CREATE DATABASE PODb
USE PODb

CREATE TABLE Supplier 
	(
		SuplNo CHAR(4) PRIMARY KEY,
		SuplName VARCHAR(15) NOT NULL,
		SuplAddress VARCHAR(40)
	)
CREATE TABLE Item 
	(
		ItCode CHAR(4) PRIMARY KEY,
		ItDesc VARCHAR(15) NOT NULL,
		ItRate MONEY
	)
CREATE TABLE PoMaster
	(
		PoNo CHAR(4) PRIMARY KEY,
		PoDate DATETIME,
		SuplNo CHAR(4) REFERENCES Supplier(SuplNo)
	)
CREATE TABLE PoDetail 
	(
		PoNo CHAR(4) REFERENCES PoMaster(PoNo),
		ItCode CHAR(4) REFERENCES Item(ItCode),
		Qty INT,
		CONSTRAINT Pod_PK PRIMARY KEY(PONO, ItCode)
	)

